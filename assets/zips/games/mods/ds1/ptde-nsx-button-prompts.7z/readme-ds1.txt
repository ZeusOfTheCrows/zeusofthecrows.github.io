This is untested as I don't own ptde. I see no reason why it shouldn't work 
though.

To install:
	Download DSFix and enable texture override
	Copy png file to [game_directory]\DATA\dsfix\tex_override