
To install:

- Download iGP11
- Unpack the files from either [w-boss-souls] or [no-boss-souls] to  [game_directory]\Game\iGP11\tex_override