To install with iPG11:
	Unpack files from .\tex_override to [game_directory]\Game\iGP11\tex_override


My nexus page: https://www.nexusmods.com/users/32740065